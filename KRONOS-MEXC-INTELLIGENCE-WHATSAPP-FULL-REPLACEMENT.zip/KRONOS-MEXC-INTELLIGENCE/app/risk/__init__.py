"""Paper portfolio risk calculations."""
