"""Forecast artifact persistence interfaces."""
