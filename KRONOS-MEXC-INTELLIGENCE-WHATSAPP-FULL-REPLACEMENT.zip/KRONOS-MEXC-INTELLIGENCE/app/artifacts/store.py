from __future__ import annotations

import gzip
from abc import ABC, abstractmethod
from io import BytesIO

import numpy as np


class ForecastArtifactStore(ABC):
    """Storage abstraction for forecast path arrays."""

    @abstractmethod
    def encode(self, paths: np.ndarray) -> bytes:
        raise NotImplementedError

    @abstractmethod
    def decode(self, blob: bytes, expected_shape: tuple[int, ...]) -> np.ndarray:
        raise NotImplementedError


class DatabaseForecastArtifactStore(ForecastArtifactStore):
    """Compressed NumPy artifacts stored in the Forecast database row.

    This default requires no extra cloud credentials. It is suitable for early
    research deployments; database growth must be monitored as forecast history
    accumulates. A future object-store backend can implement this same interface.
    """

    def encode(self, paths: np.ndarray) -> bytes:
        array = np.asarray(paths, dtype=np.float32)
        if array.ndim != 3 or array.shape[-1] != 6:
            raise ValueError("Forecast paths must have [samples, horizon, 6] shape")
        if not np.isfinite(array).all():
            raise ValueError("Forecast paths contain non-finite values")
        stream = BytesIO()
        np.save(stream, array, allow_pickle=False)
        return gzip.compress(stream.getvalue(), compresslevel=6)

    def decode(self, blob: bytes, expected_shape: tuple[int, ...]) -> np.ndarray:
        if not blob:
            raise ValueError("Forecast artifact is empty")
        array = np.load(BytesIO(gzip.decompress(blob)), allow_pickle=False)
        if tuple(array.shape) != tuple(expected_shape):
            raise ValueError("Stored forecast artifact shape mismatch")
        if not np.isfinite(array).all():
            raise ValueError("Stored forecast artifact contains non-finite values")
        return array
