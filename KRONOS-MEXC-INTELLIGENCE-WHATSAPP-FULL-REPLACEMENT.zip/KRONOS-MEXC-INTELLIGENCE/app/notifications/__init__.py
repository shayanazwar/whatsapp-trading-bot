"""Policy-constrained notification integrations."""
